/* ==========================================================================
   SS LINE CAR — shared app logic (data, i18n, navbar/footer, cars, booking)
   ========================================================================== */

/* ---------------------------- AGENCY DATA -------------------------------- */
const AGENCY = {
  name: "SS LINE CAR",
  city: "Fès",
  phoneDisplay: "06 61 79 54 57",
  phoneIntl: "212661795457",           // used for tel: and wa.me
  whatsappUrl: "https://wa.me/212661795457",
  email: "sslinecar@gmail.com",
  address: "2ème étage, N 32 Av Saint Louis, N 3 Ain Chkf, Fès, Maroc",
  hoursFr: "Ouvert 24h/24 – 7j/7",
  facebook: "https://facebook.com/[à compléter]",
  instagram: "https://instagram.com/[à compléter]",
  mapEmbed: "https://www.google.com/maps?q=Fès,Maroc&output=embed",
  cities: ["Fès", "Meknès", "Rabat", "Casablanca", "Marrakech"],
  rating: "5.0"
};

/* ------------------------------- CARS ------------------------------------ */
/* icon: which inline SVG silhouette to use (all cars share one clean icon,
   colored per card) — no external photos are referenced anywhere. */
const CARS = [
  { id: "dacia-logan",   num: "01", name: "Dacia Logan",   year: 2024, seats: 5, doors: 4, gearKey: "auto", ac: true, price: 350, color: "#f5f3ee", accent: "#0e3b39" },
  { id: "hyundai-i20",   num: "02", name: "Hyundai i20",   year: 2024, seats: 5, doors: 4, gearKey: "auto", ac: true, price: 400, color: "#e9e7e2", accent: "#1a2b2a" },
  { id: "renault-clio5", num: "03", name: "Renault Clio 5",year: 2024, seats: 5, doors: 4, gearKey: "auto", ac: true, price: 450, color: "#efece5", accent: "#111f1e" },
  { id: "kia-picanto",   num: "04", name: "Kia Picanto",   year: 2024, seats: 5, doors: 4, gearKey: "auto", ac: true, price: 300, color: "#f7f4ee", accent: "#0e3b39" }
];

function getCar(id) { return CARS.find(c => c.id === id); }

/* -------------------------------- I18N ------------------------------------ */
const TRANSLATIONS = {
  fr: {
    dir: "ltr",
    htmlLang: "fr",
    nav: { home: "Accueil", fleet: "Nos voitures", about: "À propos", conditions: "Conditions", contact: "Contact", reserve: "Réserver sur WhatsApp" },
    tagline: "Location de voitures à Fès",
    hero: {
      eyebrow: "Fès · Maroc",
      title1: "Votre trajet,",
      title2: "notre priorité.",
      subtitle: "Location de voitures fiables à Fès au meilleur prix.",
      f1: "Assurance tous risques incluse",
      f2: "Livraison aéroport gratuite",
      f3: "Service client 24/7",
      cta: "Réserver sur WhatsApp",
      live: "Réponse rapide 24/7"
    },
    statbar: { insurance: "Assurance tous risques\nincluse", delivery: "Livraison aéroport\ngratuite", open: "Ouvert 24h/24 – 7j/7", rating: "sur Google — Clients satisfaits" },
    fleet: {
      eyebrow: "Notre flotte",
      title: "Des voitures pour chaque besoin",
      perDay: "DH / jour",
      seats: "Places", doors: "Portes", gear: "Boîte", ac: "Clim A/C",
      details: "Voir détails",
      viewAll: "Voir toute la flotte",
      book: "Réserver cette voiture"
    },
    steps: {
      eyebrow: "Comment ça marche ?",
      title: "Réservez en 3 étapes simples",
      s1t: "Choisissez votre voiture", s1d: "Parcourez notre flotte et sélectionnez le véhicule qui vous convient.",
      s2t: "Sélectionnez vos dates", s2d: "Indiquez vos dates de départ et de retour en quelques secondes.",
      s3t: "Réservez sur WhatsApp", s3d: "Envoyez votre demande et recevez une confirmation immédiate."
    },
    infoGrid: {
      cities: "Villes couvertes",
      conditions: "Conditions de location",
      c1: "Âge minimum : 21 ans", c2: "Permis de conduire valable", c3: "Pièce d'identité (CIN ou Passeport)", c4: "Caution remboursable", c5: "Kilométrage illimité", c6: "Carburant : plein → plein",
      contact: "Nous contacter",
      hours: "Ouvert 24h/24 – 7j/7",
      delivery: "Livraison aéroport",
      deliveryText: "Nous vous livrons votre voiture à l'aéroport de Fès à votre arrivée."
    },
    footer: {
      tagline: "Votre partenaire de confiance pour la location de voitures à Fès et dans tout le Maroc.",
      quickLinks: "Liens rapides",
      information: "Informations",
      location: "Notre localisation",
      faq: "Questions fréquentes",
      privacy: "Politique de confidentialité",
      legal: "Mentions légales",
      rights: "SS LINE CAR. Tous droits réservés."
    },
    about: {
      eyebrow: "À propos",
      title: "Votre partenaire de confiance à Fès",
      lead: "SS LINE CAR est une agence de location de voitures basée à Fès, au service des voyageurs et des habitants dans plusieurs villes du Maroc.",
      p1: "Depuis notre agence, nous mettons à votre disposition une flotte de véhicules récents, entretenus et assurés tous risques, pour vos déplacements professionnels, touristiques ou personnels.",
      p2: "Notre objectif est simple : vous offrir un service rapide, transparent et disponible 24h/24, avec une livraison possible directement à l'aéroport de Fès.",
      valuesTitle: "Pourquoi nous choisir ?",
      v1t: "Assurance tous risques", v1d: "Chaque location inclut une assurance complète, sans mauvaise surprise.",
      v2t: "Livraison aéroport", v2d: "Récupérez votre voiture dès votre arrivée à l'aéroport de Fès.",
      v3t: "Disponibilité 24/7", v3d: "Une équipe joignable à tout moment sur WhatsApp.",
      v4t: "Kilométrage illimité", v4d: "Roulez sans compter les kilomètres, où que vous alliez.",
      citiesTitle: "Villes couvertes",
      citiesText: "Nous intervenons à Fès et dans plusieurs grandes villes du Maroc.",
      contactTitle: "Nos coordonnées",
      mapTitle: "Notre localisation"
    },
    reservation: {
      eyebrow: "Réservation",
      title: "Réservez votre voiture",
      subtitle: "Remplissez le formulaire ci-dessous, votre demande sera envoyée directement sur WhatsApp.",
      name: "Nom complet", namePh: "Votre nom",
      phone: "Téléphone", phonePh: "06 XX XX XX XX",
      car: "Voiture souhaitée", carPh: "Choisir une voiture",
      start: "Date de départ", end: "Date de retour",
      place: "Lieu de prise en charge", placePh: "Ex : Aéroport de Fès, Agence, Hôtel...",
      message: "Message (optionnel)", messagePh: "Précisions supplémentaires...",
      submit: "Confirmer sur WhatsApp",
      note: "En confirmant, vous serez redirigé vers WhatsApp avec votre demande déjà rédigée.",
      required: "Merci de remplir les champs obligatoires."
    },
    wa: {
      greeting: "Bonjour SS LINE CAR 👋",
      intent: "Je souhaite réserver une voiture :",
      car: "Voiture", period: "Période", from: "Du", to: "au", place: "Lieu de prise en charge", name: "Nom", phone: "Téléphone", message: "Message", notSpecified: "Non précisé"
    }
  },

  ar: {
    dir: "rtl",
    htmlLang: "ar",
    nav: { home: "الرئيسية", fleet: "سياراتنا", about: "من نحن", conditions: "الشروط", contact: "اتصل بنا", reserve: "احجز عبر واتساب" },
    tagline: "كراء السيارات بفاس",
    hero: {
      eyebrow: "فاس · المغرب",
      title1: "طريقك،",
      title2: "أولويتنا.",
      subtitle: "كراء سيارات موثوقة بفاس بأفضل الأثمنة.",
      f1: "تأمين شامل مضمّن",
      f2: "توصيل مجاني للمطار",
      f3: "خدمة الزبناء 24/7",
      cta: "احجز عبر واتساب",
      live: "جواب سريع 24/7"
    },
    statbar: { insurance: "تأمين شامل\nمضمّن", delivery: "توصيل للمطار\nمجاني", open: "مفتوحين 24 ساعة – 7 أيام", rating: "فـ Google — زبناء راضيين" },
    fleet: {
      eyebrow: "أسطولنا",
      title: "سيارات لكل احتياج",
      perDay: "درهم / اليوم",
      seats: "بلايص", doors: "أبواب", gear: "الفيتيس", ac: "كليماتيزور",
      details: "التفاصيل",
      viewAll: "شوف كل الأسطول",
      book: "احجز هاد السيارة"
    },
    steps: {
      eyebrow: "كيفاش كتخدم؟",
      title: "احجز فـ 3 خطوات سهلة",
      s1t: "اختار السيارة ديالك", s1d: "تصفح أسطولنا واختار السيارة اللي كتناسبك.",
      s2t: "اختار التواريخ", s2d: "حدد تاريخ الانطلاق والرجوع فثواني قليلة.",
      s3t: "احجز عبر واتساب", s3d: "صيفط طلبك وتوصل بالتأكيد فالحين."
    },
    infoGrid: {
      cities: "المدن اللي كنغطيو",
      conditions: "شروط الكراء",
      c1: "السن الأدنى: 21 عام", c2: "رخصة السياقة صالحة", c3: "بطاقة الهوية (CIN أو جواز السفر)", c4: "تأمين قابل للاسترجاع", c5: "كيلومتراج غير محدود", c6: "الوقود: كامل ← كامل",
      contact: "اتصل بنا",
      hours: "مفتوحين 24 ساعة – 7 أيام",
      delivery: "توصيل للمطار",
      deliveryText: "كنوصلوك السيارة لمطار فاس بمجرد وصولك."
    },
    footer: {
      tagline: "الشريك اللي تتوثق فيه لكراء السيارات بفاس وفكامل المغرب.",
      quickLinks: "روابط سريعة",
      information: "معلومات",
      location: "الموقع ديالنا",
      faq: "الأسئلة الشائعة",
      privacy: "سياسة الخصوصية",
      legal: "الإشعارات القانونية",
      rights: "SS LINE CAR. جميع الحقوق محفوظة."
    },
    about: {
      eyebrow: "من نحن",
      title: "الشريك اللي تتوثق فيه بفاس",
      lead: "SS LINE CAR وكالة لكراء السيارات مقرها فاس، فخدمة المسافرين والساكنة فبزاف من مدن المغرب.",
      p1: "من الوكالة ديالنا، كنوفرو ليك أسطول من السيارات الحديثة، مصانة ومؤمّنة تأمين شامل، للتنقلات المهنية والسياحية والشخصية ديالك.",
      p2: "الهدف ديالنا بسيط: نوفرو ليك خدمة سريعة، واضحة، ومتوفرة 24 ساعة على 24، مع إمكانية التوصيل مباشرة لمطار فاس.",
      valuesTitle: "علاش تختارنا؟",
      v1t: "تأمين شامل", v1d: "كل كراء فيه تأمين كامل، بلا مفاجآت.",
      v2t: "توصيل للمطار", v2d: "استرجع السيارة ديالك مباشرة بعد وصولك لمطار فاس.",
      v3t: "متوفرين 24/7", v3d: "فريق كنقدر توصل ليه فأي وقت عبر واتساب.",
      v4t: "كيلومتراج غير محدود", v4d: "سوق بلا ما تحسب الكيلومترات، فأي بلاصة غاديك.",
      citiesTitle: "المدن اللي كنغطيو",
      citiesText: "كنخدمو فاس وبزاف من المدن الكبيرة فالمغرب.",
      contactTitle: "معلومات الاتصال",
      mapTitle: "الموقع ديالنا"
    },
    reservation: {
      eyebrow: "الحجز",
      title: "احجز السيارة ديالك",
      subtitle: "عمر الفورم لتحت، وطلبك غادي يتصيفط مباشرة لواتساب.",
      name: "الاسم الكامل", namePh: "سميتك",
      phone: "رقم الهاتف", phonePh: "06 XX XX XX XX",
      car: "السيارة المرغوبة", carPh: "اختار سيارة",
      start: "تاريخ الانطلاق", end: "تاريخ الرجوع",
      place: "بلاصة الاستلام", placePh: "مثلا: مطار فاس، الوكالة، الفندق...",
      message: "رسالة (اختياري)", messagePh: "تفاصيل زايدة...",
      submit: "أكّد عبر واتساب",
      note: "من بعد التأكيد، غادي تتوجه لواتساب مع الطلب ديالك محضّر.",
      required: "عافاك عمر الخانات المطلوبة."
    },
    wa: {
      greeting: "سلام SS LINE CAR 👋",
      intent: "بغيت نحجز سيارة:",
      car: "السيارة", period: "المدة", from: "من", to: "إلى", place: "بلاصة الاستلام", name: "الاسم", phone: "الهاتف", message: "رسالة", notSpecified: "ماشي محدد"
    }
  },

  en: {
    dir: "ltr",
    htmlLang: "en",
    nav: { home: "Home", fleet: "Our cars", about: "About", conditions: "Conditions", contact: "Contact", reserve: "Book on WhatsApp" },
    tagline: "Car rental in Fès",
    hero: {
      eyebrow: "Fès · Morocco",
      title1: "Your journey,",
      title2: "our priority.",
      subtitle: "Reliable car rental in Fès at the best price.",
      f1: "Full insurance included",
      f2: "Free airport delivery",
      f3: "24/7 customer service",
      cta: "Book on WhatsApp",
      live: "Fast reply 24/7"
    },
    statbar: { insurance: "Full insurance\nincluded", delivery: "Free airport\ndelivery", open: "Open 24/7", rating: "on Google — Happy customers" },
    fleet: {
      eyebrow: "Our fleet",
      title: "A car for every need",
      perDay: "DH / day",
      seats: "Seats", doors: "Doors", gear: "Gearbox", ac: "A/C",
      details: "View details",
      viewAll: "View full fleet",
      book: "Book this car"
    },
    steps: {
      eyebrow: "How it works",
      title: "Book in 3 simple steps",
      s1t: "Choose your car", s1d: "Browse our fleet and pick the vehicle that suits you.",
      s2t: "Select your dates", s2d: "Set your pick-up and return dates in a few seconds.",
      s3t: "Book on WhatsApp", s3d: "Send your request and get an instant confirmation."
    },
    infoGrid: {
      cities: "Cities covered",
      conditions: "Rental conditions",
      c1: "Minimum age: 21 years", c2: "Valid driving licence", c3: "ID (national ID or passport)", c4: "Refundable deposit", c5: "Unlimited mileage", c6: "Fuel policy: full → full",
      contact: "Contact us",
      hours: "Open 24/7",
      delivery: "Airport delivery",
      deliveryText: "We deliver your car to Fès airport upon your arrival."
    },
    footer: {
      tagline: "Your trusted partner for car rental in Fès and across Morocco.",
      quickLinks: "Quick links",
      information: "Information",
      location: "Our location",
      faq: "FAQ",
      privacy: "Privacy policy",
      legal: "Legal notice",
      rights: "SS LINE CAR. All rights reserved."
    },
    about: {
      eyebrow: "About us",
      title: "Your trusted partner in Fès",
      lead: "SS LINE CAR is a car rental agency based in Fès, serving travelers and residents across several cities in Morocco.",
      p1: "From our agency, we provide a fleet of recent, well-maintained, fully insured vehicles for your business, leisure or personal trips.",
      p2: "Our goal is simple: fast, transparent service available 24/7, with delivery available directly to Fès airport.",
      valuesTitle: "Why choose us?",
      v1t: "Full insurance", v1d: "Every rental includes comprehensive insurance, no surprises.",
      v2t: "Airport delivery", v2d: "Pick up your car as soon as you land at Fès airport.",
      v3t: "24/7 availability", v3d: "A team reachable anytime on WhatsApp.",
      v4t: "Unlimited mileage", v4d: "Drive without counting the kilometers, wherever you go.",
      citiesTitle: "Cities covered",
      citiesText: "We operate in Fès and in several major cities across Morocco.",
      contactTitle: "Contact details",
      mapTitle: "Our location"
    },
    reservation: {
      eyebrow: "Reservation",
      title: "Book your car",
      subtitle: "Fill in the form below, your request will be sent directly on WhatsApp.",
      name: "Full name", namePh: "Your name",
      phone: "Phone", phonePh: "06 XX XX XX XX",
      car: "Desired car", carPh: "Choose a car",
      start: "Pick-up date", end: "Return date",
      place: "Pick-up location", placePh: "E.g. Fès airport, agency, hotel...",
      message: "Message (optional)", messagePh: "Any extra details...",
      submit: "Confirm on WhatsApp",
      note: "After confirming, you'll be redirected to WhatsApp with your request already written.",
      required: "Please fill in the required fields."
    },
    wa: {
      greeting: "Hello SS LINE CAR 👋",
      intent: "I would like to book a car:",
      car: "Car", period: "Period", from: "From", to: "to", place: "Pick-up location", name: "Name", phone: "Phone", message: "Message", notSpecified: "Not specified"
    }
  }
};

/* ---------------------------- LANGUAGE STATE ------------------------------ */
const SUPPORTED_LANGS = ["fr", "ar", "en"];

function detectLang() {
  const stored = localStorage.getItem("sslc_lang");
  if (stored && SUPPORTED_LANGS.includes(stored)) return stored;
  const nav = (navigator.language || "fr").toLowerCase();
  if (nav.startsWith("ar")) return "ar";
  if (nav.startsWith("en")) return "en";
  return "fr";
}

let CURRENT_LANG = detectLang();

function t(path) {
  const parts = path.split(".");
  let node = TRANSLATIONS[CURRENT_LANG];
  for (const p of parts) {
    if (node == null) return "";
    node = node[p];
  }
  return node == null ? "" : node;
}

function applyLang(lang) {
  CURRENT_LANG = SUPPORTED_LANGS.includes(lang) ? lang : "fr";
  localStorage.setItem("sslc_lang", CURRENT_LANG);
  const dict = TRANSLATIONS[CURRENT_LANG];
  document.documentElement.setAttribute("lang", dict.htmlLang);
  document.documentElement.setAttribute("dir", dict.dir);
  document.body.classList.toggle("font-arabic", CURRENT_LANG === "ar");

  document.querySelectorAll("[data-i18n]").forEach(el => {
    const val = t(el.getAttribute("data-i18n"));
    if (typeof val === "string") el.textContent = val;
  });
  document.querySelectorAll("[data-i18n-html]").forEach(el => {
    const val = t(el.getAttribute("data-i18n-html"));
    if (typeof val === "string") el.innerHTML = val.replace(/\n/g, "<br>");
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach(el => {
    const val = t(el.getAttribute("data-i18n-placeholder"));
    if (typeof val === "string") el.setAttribute("placeholder", val);
  });

  document.querySelectorAll("[data-lang-btn]").forEach(btn => {
    btn.classList.toggle("is-active", btn.getAttribute("data-lang-btn") === CURRENT_LANG);
  });

  fillCardLabels(document);
  if (typeof onLangApplied === "function") onLangApplied();
}

/* ------------------------------ SVG ICONS ---------------------------------- */
const ICONS = {
  shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3z"/></svg>`,
  plane: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M10.5 21l1.5-6 7-4-1-2-7 2-4-4-2 1 2.5 4.5-4 1v2l4-1 1 5 2-1z"/></svg>`,
  headset: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M4 13v-1a8 8 0 0116 0v1"/><rect x="3" y="13" width="4" height="6" rx="1.3"/><rect x="17" y="13" width="4" height="6" rx="1.3"/><path d="M19 19a4 4 0 01-4 3h-2"/></svg>`,
  clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>`,
  star: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5l3 6.2 6.8.9-5 4.7 1.3 6.8L12 17.9 5.9 21.1l1.3-6.8-5-4.7 6.8-.9L12 2.5z"/></svg>`,
  seats: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><circle cx="12" cy="6" r="2.4"/><path d="M6 20l1.5-7a3 3 0 013-2.3h3a3 3 0 013 2.3L18 20"/></svg>`,
  doors: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="5" y="3" width="14" height="18" rx="1.5"/><path d="M9 3v18"/></svg>`,
  gear: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 3v4M12 17v4M4.2 7l3.5 2M16.3 15l3.5 2M4.2 17l3.5-2M16.3 9l3.5-2"/><circle cx="12" cy="12" r="3.2"/></svg>`,
  snow: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 2v20M4 7l16 10M20 7L4 17"/></svg>`,
  pin: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 21s7-6.3 7-12a7 7 0 10-14 0c0 5.7 7 12 7 12z"/><circle cx="12" cy="9" r="2.4"/></svg>`,
  mail: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12.5l4.5 4.5L19 7"/></svg>`,
  car: `<svg viewBox="0 0 64 40" fill="none"><path d="M6 27h52l-4-11a6 6 0 00-5.6-3.9H15.6A6 6 0 0010 15.1L6 27z" fill="currentColor" opacity=".9"/><rect x="2" y="27" width="60" height="7" rx="3.5" fill="currentColor"/><circle cx="16" cy="35" r="5" fill="#111f1e"/><circle cx="48" cy="35" r="5" fill="#111f1e"/><circle cx="16" cy="35" r="2" fill="#e9e2cf"/><circle cx="48" cy="35" r="2" fill="#e9e2cf"/><path d="M17 14.5l2.3-6.4a2 2 0 011.9-1.4h21.6a2 2 0 011.9 1.4l2.3 6.4" stroke="currentColor" stroke-width="1.4" opacity=".55"/></svg>`,
  whatsapp: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 00-8.6 15.1L2 22l5.1-1.3A10 10 0 1012 2zm0 18a8 8 0 01-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8 8 0 1112 20zm4.4-5.8c-.2-.1-1.4-.7-1.6-.8-.2-.1-.4-.1-.6.1-.2.2-.6.8-.8 1-.1.2-.3.2-.5.1-.2-.1-1-.4-2-1.2-.7-.6-1.2-1.4-1.4-1.6-.1-.2 0-.4.1-.5.1-.1.2-.3.4-.4.1-.1.2-.2.2-.4.1-.2 0-.3 0-.4-.1-.1-.6-1.4-.8-1.9-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.4.1-.6.3-.2.2-.8.8-.8 1.9 0 1.1.8 2.2.9 2.4.1.2 1.6 2.5 4 3.4.6.2 1 .4 1.3.5.6.2 1.1.2 1.5.1.5-.1 1.4-.6 1.6-1.1.2-.5.2-1 .1-1.1-.1-.1-.2-.1-.4-.2z"/></svg>`,
  facebook: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 9h3V6h-3c-2 0-3.5 1.5-3.5 3.5V11H8v3h2.5v7h3v-7H16l.5-3h-3V9.7c0-.4.3-.7.5-.7z"/></svg>`,
  instagram: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1"/></svg>`
};

/* ------------------------------- NAVBAR ------------------------------------ */
function currentPageKey() {
  return document.body.getAttribute("data-page") || "home";
}

function renderNavbar(rootPrefix) {
  const el = document.getElementById("site-navbar");
  if (!el) return;
  const page = currentPageKey();
  const linkClass = (key) =>
    "nav-link" + (page === key ? " nav-link-active" : "");

  el.innerHTML = `
    <div class="max-w-7xl mx-auto px-5 md:px-8">
      <div class="flex items-center justify-between h-20 md:h-24">
        <a href="${rootPrefix}index.html" class="flex items-center gap-3 shrink-0">
          <span class="sslc-logo">SS</span>
          <span class="leading-tight">
            <span class="block font-serif text-lg md:text-xl tracking-wide text-[color:var(--teal-900)]">${AGENCY.name}</span>
            <span class="block text-[10px] md:text-[11px] tracking-[0.18em] uppercase text-[color:var(--teal-600)]" data-i18n="tagline">${t("tagline")}</span>
          </span>
        </a>

        <nav class="hidden lg:flex items-center gap-8 font-medium text-sm tracking-wide">
          <a href="${rootPrefix}index.html" class="${linkClass("home")}" data-i18n="nav.home">${t("nav.home")}</a>
          <a href="${rootPrefix}flotte/index.html" class="${linkClass("flotte")}" data-i18n="nav.fleet">${t("nav.fleet")}</a>
          <a href="${rootPrefix}agence/index.html" class="${linkClass("agence")}" data-i18n="nav.about">${t("nav.about")}</a>
          <a href="${rootPrefix}index.html#conditions" class="nav-link" data-i18n="nav.conditions">${t("nav.conditions")}</a>
          <a href="${rootPrefix}index.html#contact" class="nav-link" data-i18n="nav.contact">${t("nav.contact")}</a>
        </nav>

        <div class="flex items-center gap-2 md:gap-3">
          <div class="lang-switch" role="group" aria-label="Language">
            <button type="button" data-lang-btn="fr" onclick="applyLang('fr')">FR</button>
            <button type="button" data-lang-btn="ar" onclick="applyLang('ar')">ع</button>
            <button type="button" data-lang-btn="en" onclick="applyLang('en')">EN</button>
          </div>
          <a href="${rootPrefix}reservation/index.html" class="btn-primary hidden md:inline-flex">
            <span class="w-4 h-4">${ICONS.whatsapp}</span>
            <span data-i18n="nav.reserve">${t("nav.reserve")}</span>
          </a>
          <button id="burger-btn" class="lg:hidden w-10 h-10 grid place-items-center rounded-full border border-[color:var(--teal-900)]/20" aria-label="Menu">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
          </button>
        </div>
      </div>

      <div id="mobile-menu" class="hidden lg:hidden pb-6 flex flex-col gap-4 font-medium text-sm border-t border-[color:var(--teal-900)]/10 pt-4">
        <a href="${rootPrefix}index.html" data-i18n="nav.home">${t("nav.home")}</a>
        <a href="${rootPrefix}flotte/index.html" data-i18n="nav.fleet">${t("nav.fleet")}</a>
        <a href="${rootPrefix}agence/index.html" data-i18n="nav.about">${t("nav.about")}</a>
        <a href="${rootPrefix}index.html#conditions" data-i18n="nav.conditions">${t("nav.conditions")}</a>
        <a href="${rootPrefix}index.html#contact" data-i18n="nav.contact">${t("nav.contact")}</a>
        <a href="${rootPrefix}reservation/index.html" class="btn-primary justify-center">
          <span class="w-4 h-4">${ICONS.whatsapp}</span>
          <span data-i18n="nav.reserve">${t("nav.reserve")}</span>
        </a>
      </div>
    </div>
  `;

  const burger = document.getElementById("burger-btn");
  const menu = document.getElementById("mobile-menu");
  if (burger && menu) {
    burger.addEventListener("click", () => menu.classList.toggle("hidden"));
  }
}

/* -------------------------------- FOOTER ------------------------------------ */
function renderFooter(rootPrefix) {
  const el = document.getElementById("site-footer");
  if (!el) return;
  el.innerHTML = `
    <div class="max-w-7xl mx-auto px-5 md:px-8 py-16 grid gap-10 md:grid-cols-4">
      <div>
        <a href="${rootPrefix}index.html" class="flex items-center gap-3 mb-4">
          <span class="sslc-logo sslc-logo-light">SS</span>
          <span class="font-serif text-lg tracking-wide text-[color:var(--gold-400)]">${AGENCY.name}</span>
        </a>
        <p class="text-sm text-cream-200/80 leading-relaxed max-w-xs" data-i18n="footer.tagline">${t("footer.tagline")}</p>
        <div class="flex items-center gap-3 mt-5">
          <a href="${AGENCY.facebook}" target="_blank" rel="noopener" class="footer-social" aria-label="Facebook">${ICONS.facebook}</a>
          <a href="${AGENCY.instagram}" target="_blank" rel="noopener" class="footer-social" aria-label="Instagram">${ICONS.instagram}</a>
          <a href="${AGENCY.whatsappUrl}" target="_blank" rel="noopener" class="footer-social" aria-label="WhatsApp">${ICONS.whatsapp}</a>
        </div>
      </div>

      <div>
        <h4 class="footer-title" data-i18n="footer.quickLinks">${t("footer.quickLinks")}</h4>
        <ul class="footer-list">
          <li><a href="${rootPrefix}index.html" data-i18n="nav.home">${t("nav.home")}</a></li>
          <li><a href="${rootPrefix}flotte/index.html" data-i18n="nav.fleet">${t("nav.fleet")}</a></li>
          <li><a href="${rootPrefix}agence/index.html" data-i18n="nav.about">${t("nav.about")}</a></li>
          <li><a href="${rootPrefix}index.html#conditions" data-i18n="nav.conditions">${t("nav.conditions")}</a></li>
          <li><a href="${rootPrefix}index.html#contact" data-i18n="nav.contact">${t("nav.contact")}</a></li>
        </ul>
      </div>

      <div>
        <h4 class="footer-title" data-i18n="footer.information">${t("footer.information")}</h4>
        <ul class="footer-list">
          <li><a href="${rootPrefix}index.html#conditions" data-i18n="footer.quickLinks">${t("infoGrid.conditions")}</a></li>
          <li><a href="#" data-i18n="footer.faq">${t("footer.faq")}</a></li>
          <li><a href="${rootPrefix}index.html#contact" data-i18n="infoGrid.delivery">${t("infoGrid.delivery")}</a></li>
          <li><a href="#" data-i18n="footer.privacy">${t("footer.privacy")}</a></li>
          <li><a href="#" data-i18n="footer.legal">${t("footer.legal")}</a></li>
        </ul>
      </div>

      <div>
        <h4 class="footer-title" data-i18n="footer.location">${t("footer.location")}</h4>
        <div class="rounded-xl overflow-hidden border border-white/15 h-36">
          <iframe src="${AGENCY.mapEmbed}" class="w-full h-full grayscale contrast-125" loading="lazy" title="${AGENCY.name} map"></iframe>
        </div>
      </div>
    </div>
    <div class="border-t border-white/10">
      <div class="max-w-7xl mx-auto px-5 md:px-8 py-5 text-xs text-cream-200/60 flex flex-col md:flex-row gap-2 items-center justify-between">
        <p>© <span id="footer-year"></span> <span data-i18n="footer.rights">${t("footer.rights")}</span></p>
        <p>${AGENCY.city} · Maroc</p>
      </div>
    </div>
  `;
  const y = document.getElementById("footer-year");
  if (y) y.textContent = new Date().getFullYear();
}

/* ------------------------------ FLEET CARDS -------------------------------- */
function carCardHTML(car, rootPrefix, opts = {}) {
  const big = opts.big ? "car-card-big" : "";
  return `
    <article class="car-card ${big}" style="--card-bg:${car.color}">
      <div class="car-card-num">${car.num}</div>
      <div class="car-card-visual" style="color:${car.accent}">
        ${ICONS.car}
      </div>
      <div class="car-card-body">
        <h3 class="font-serif text-xl text-[color:var(--teal-900)]">${car.name}</h3>
        <p class="text-xs text-[color:var(--teal-600)] mb-3">${car.year} · <span class="gear-inline"></span></p>
        <div class="grid grid-cols-4 gap-2 text-[11px] text-[color:var(--teal-700)] mb-4">
          <div class="flex flex-col items-center gap-1"><span class="w-4 h-4">${ICONS.seats}</span>${car.seats}</div>
          <div class="flex flex-col items-center gap-1"><span class="w-4 h-4">${ICONS.doors}</span>${car.doors}</div>
          <div class="flex flex-col items-center gap-1"><span class="w-4 h-4">${ICONS.gear}</span><span class="gear-label"></span></div>
          <div class="flex flex-col items-center gap-1"><span class="w-4 h-4">${ICONS.snow}</span><span class="ac-label"></span></div>
        </div>
        <div class="flex items-end justify-between mb-4">
          <div><span class="text-2xl font-serif text-[color:var(--teal-900)]">${car.price}</span> <span class="text-xs text-[color:var(--teal-600)] per-day-label"></span></div>
        </div>
        <a href="${rootPrefix}reservation/index.html?car=${car.id}" class="btn-outline w-full justify-center book-label"></a>
      </div>
    </article>
  `;
}

function fillCardLabels(root = document) {
  root.querySelectorAll(".gear-inline").forEach(el => el.textContent = t("fleet.gear"));
  root.querySelectorAll(".gear-label").forEach(el => el.textContent = t("fleet.gear"));
  root.querySelectorAll(".ac-label").forEach(el => el.textContent = t("fleet.ac"));
  root.querySelectorAll(".per-day-label").forEach(el => el.textContent = t("fleet.perDay"));
  root.querySelectorAll(".book-label").forEach(el => el.textContent = t("fleet.book"));
}

function renderCarGrid(containerId, rootPrefix, opts = {}) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const list = opts.limit ? CARS.slice(0, opts.limit) : CARS;
  el.innerHTML = list.map(c => carCardHTML(c, rootPrefix, opts)).join("");
  fillCardLabels(el);
}

/* ---------------------------- WHATSAPP BOOKING ------------------------------ */
function buildWhatsAppMessage({ carName, start, end, place, name, phone, message }) {
  const w = TRANSLATIONS[CURRENT_LANG].wa;
  const lines = [
    w.greeting,
    "",
    w.intent,
    `🚗 ${w.car}: ${carName || w.notSpecified}`,
    `📅 ${w.period}: ${w.from} ${start || "—"} ${w.to} ${end || "—"}`,
    `📍 ${w.place}: ${place || w.notSpecified}`,
    `🙋 ${w.name}: ${name || w.notSpecified}`,
    `📞 ${w.phone}: ${phone || w.notSpecified}`
  ];
  if (message) lines.push(`✏️ ${w.message}: ${message}`);
  return lines.join("\n");
}

function openWhatsAppBooking(data) {
  const msg = buildWhatsAppMessage(data);
  const url = `${AGENCY.whatsappUrl}?text=${encodeURIComponent(msg)}`;
  window.open(url, "_blank");
}

/* ----------------------------- URL PARAM HELPER ------------------------------ */
function getUrlParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

/* --------------------------------- INIT --------------------------------------
   Each page calls initPage(rootPrefix) after DOM is ready, then applyLang().
----------------------------------------------------------------------------- */
function initPage(rootPrefix) {
  renderNavbar(rootPrefix);
  renderFooter(rootPrefix);
  applyLang(CURRENT_LANG);
  initRevealOnScroll();
}

/* ------------------------------ SCROLL REVEAL --------------------------------- */
function initRevealOnScroll() {
  const items = document.querySelectorAll("[data-reveal]");
  if (!items.length || !("IntersectionObserver" in window)) {
    items.forEach(el => el.classList.add("is-visible"));
    return;
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  items.forEach(el => io.observe(el));
}
